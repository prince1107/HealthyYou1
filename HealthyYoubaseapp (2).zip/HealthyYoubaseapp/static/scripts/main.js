$(document).ready(function(){

    console.log("Hello!");

    /* Only add logic here that you ABSOLUTELY CANNOT add to app.py */

});