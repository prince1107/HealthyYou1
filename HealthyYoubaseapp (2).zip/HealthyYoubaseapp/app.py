from flask import Flask, render_template, request, redirect
from random import randint
import tkinter
from tkinter import messagebox


app = Flask(__name__)

# This code is to hide the main tkinter window
root = tkinter.Tk()
root.withdraw()

'''
Note: this sample code does NOT store the foods data to a database.
Instead, we store the foods data in memory in the below "foods" Python object.
Consequently, the foods data is reset every time the application is restarted.
If you would like, you can replace this foods data structure with your own database connection logic.
'''

foods = [
    {
        "id": 1,
        "name": "Spanakopita",
        "cuisine": "Greek",
        "calorie": 160,
        "photo_name": "Spanakopita.jpg",
        "available_for_adoption": True
    },
    {
        "id": 2,
        "name": "Falafel",
        "cuisine": "Israeli",
        "calorie": "5.5 per ball",
        "photo_name": "Falafel.jpg",
        "available_for_adoption": True
    },
    {
        "id": 3,
        "name": "Sushi",
        "cuisine": "Japanese",
        "calorie": "300 to 500",
        "photo_name": "sushi.jpg",
        "available_for_adoption": True
    },
    {
        "id": 4,
        "name": "Dosa",
        "cuisine": "Indian",
        "calorie": 138,
        "photo_name": "dosa.jpg",
        "available_for_adoption": True
    },
    {
        "id": 5,
        "name": "Som Tam",
        "cuisine": "Thai",
        "calorie": 125,
        "photo_name": "somtam.jpg",
        "available_for_adoption": True
    },
    {
        "id": 6,
        "name": "Kimchi Salad with rice",
        "cuisine": "South Korean",
        "calorie": 100,
        "photo_name": "kimchi.jpg",
        "available_for_adoption": True
    },
    {
        "id": 7,
        "name": "Tapas",
        "cuisine": "Spain",
        "calorie": 300,
        "photo_name": "tapas.jpg",
        "available_for_adoption": True
    },
    {
        "id": 8,
        "name": "Open faced sandwich of sliced boiled egg topped with Kalle’s kaviar and sprinkled with chopped chives",
        "cuisine": "Swedish",
        "calorie": "250 to 500",
        "photo_name": "swedishsandwich.jpg",
        "available_for_adoption": True
    }
]


@app.route('/', methods=['GET'])
@app.route('/home', methods=['GET'])
def index():
    return render_template('index.html')


@app.route('/foods', methods=['GET'])
@app.route('/foods/<food_id>', methods=['GET'])
def all_foods(food_id=None):
    return render_template('foods.html', foods=foods)

@app.route('/diet', methods=['GET'])

@app.route('/diet/<food_id>', methods=['GET'])
def diet(food_id=None):
    return render_template('diet.html', diet=diet)



@app.route('/calculate-diet', methods=['GET', 'POST'])
def calculate_diet():
    food_diet = request.form['food_diet']
    food_cuisine1 = request.form['food_cuisine1']
    food_age = request.form['food_age']
            

# Message Box
    if food_cuisine1 == "greek":
        messagebox.showinfo("Recommendation", "Spanakopita")


    elif food_cuisine1 == "israeli":
        messagebox.showinfo("Recommendation", "Falafel")
       

    elif food_cuisine1 == "japanese":
        messagebox.showinfo("Recommendation", "Sushi")
        
        
    elif food_cuisine1 == "indian":
        messagebox.showinfo("Recommendation", "Dosa")
        
        
    elif food_cuisine1 == "thai":
        messagebox.showinfo("Recommendation", "Som Tam")
        
        
    elif food_cuisine1 == "SK":
        messagebox.showinfo("Recommendation", "Kimchi Salad with rice")
        
        
    elif food_cuisine1 == "spain":
        messagebox.showinfo("Recommendation", "Tapas")
        
        
    elif food_cuisine1 == "swedish":
        messagebox.showinfo("Recommendation", "Open faced sandwich of sliced boiled egg")
    
    return redirect('/foods')


if __name__ == "__main__":
    app.run(debug=True)
